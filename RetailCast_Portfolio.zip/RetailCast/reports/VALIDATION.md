# Delivery verification

Verified on Python 3.12.14 / Windows using the versions in `requirements-lock.txt`.

| Check | Result | Scope |
|---|---|---|
| pytest | 14 passed | Data contracts, label purging, future perturbation, model invariance, seasonal baseline, MASE and intervals |
| Artifact audit | Passed | Source row count, processed SHA-256, cleaning audit, split chronology, locked selection, actual values, final metrics and interval radii |
| Research notebook | 11 code cells executed, no cell errors | Includes an actual GBM refit and numerical match to one published validation fold |
| Python compile | Passed | Source modules, app and audit script |
| Offline dashboard logic | Passed | Five markets × two modes, 28 rows per forecast, six candidate comparisons, SVG generation and CSV-export branches |
| Streamlit AppTest | Passed | All five market selectors and historical continuation, no application exceptions |
| Static scientific figures | Visually inspected | Validation leaderboard and error/coverage diagnostics |

The in-app browser could not reach the temporary localhost server and timed out. A rendered-browser review of the HTML dashboard, responsive layout and actual browser downloads was therefore not completed. The JavaScript logic check used a small DOM stub and is not equivalent to a browser visual test. Streamlit AppTest is framework-level execution, not a full browser interaction test.

The GitHub Actions workflow is supplied but has not run on GitHub. No public repository or hosted deployment has been created. Reported metrics measure one historical 28-day holdout and do not establish production utility or universal superiority.

To rerun the core checks from the repository root:

```shell
python -m pytest -q
python scripts/audit_artifacts.py
```

Open the notebook and run all cells after installing the project and development dependencies to reproduce its research checks.
