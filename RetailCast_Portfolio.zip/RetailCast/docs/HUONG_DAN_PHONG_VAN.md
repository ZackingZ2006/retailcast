# Học project và trình bày khi ứng tuyển

## Đọc theo thứ tự
1. `reports/BAO_CAO_KET_QUA.md`: biết bài toán, số liệu thực và giới hạn.
2. `notebooks/01_research.ipynb`: đọc biểu đồ, kiểm tra dữ liệu và suy luận.
3. `docs/METHODOLOGY.md`: hiểu protocol; mở `temporal_splits.csv` để xem ngày cụ thể.
4. `src/retailcast/features.py` và `tests/test_temporal_integrity.py`: hiểu vì sao dự báo 28 ngày không bị leakage.
5. `models.py`, `evaluation.py`, `pipeline.py`: lần theo train → chọn → hiệu chỉnh → test → refit.
6. Chạy lại tests và pipeline, rồi tự giải thích một lần dự báo từ dữ liệu đầu vào.

## Pitch khoảng 90 giây
“Tôi xây RetailCast để dự báo số lượng hàng bán mỗi ngày trong 28 ngày tới cho năm thị trường, từ giao dịch UCI Online Retail II. Tôi so sánh hai baseline mùa vụ, ETS, Ridge và hai cấu hình gradient boosting. Tôi dùng bốn cửa sổ validation theo thời gian để chọn thuật toán riêng cho từng thị trường, hai cửa sổ hiệu chỉnh khoảng dự báo và một cửa sổ holdout cuối. Điểm quan trọng là mỗi batch 28 ngày giữ nguyên thông tin tại ngày dự báo và loại tất cả nhãn huấn luyện vượt cutoff. Tôi báo cáo WAPE, MASE, bias và độ phủ thực tế, kể cả những thị trường mô hình không thắng baseline. Giới hạn chính là dữ liệu chỉ ghi nhận hàng đã bán và thiếu tồn kho, khuyến mại, lead time.”

Sau đó bổ sung **số liệu đúng từ báo cáo đã chạy**, không tự nhớ hoặc điền một con số đẹp.

## Các câu hỏi cần trả lời được

**Tại sao không random train/test split?**
Random split trộn quá khứ và tương lai, không mô phỏng quyết định dự báo thực tế. Những ví dụ nhiều horizon còn có thể chung nhãn giữa các nhóm. Chia theo cutoff và purge theo target date mới phù hợp.

**Lag-1 có dùng được khi dự báo ngày thứ 28 không?**
Lag-1 tính tại target cần actual ngày 27 nên chưa biết. Ở đây lag-1 là ngày cuối đã quan sát tại origin, được giữ cố định cho mọi horizon; target calendar và horizon phân biệt các ngày tương lai.

**Direct forecasting khác recursive thế nào?**
Direct học quan hệ từ origin tới từng horizon, ở đây gộp horizon thành một feature trong một global model. Recursive dự báo từng bước rồi dùng chính dự báo làm lag bước sau; có nguy cơ tích lũy sai số. Direct có nhiều ví dụ tương quan và phải purge nhãn đúng.

**Vì sao vẫn giữ baseline đơn giản?**
Để biết độ phức tạp có mang lại giá trị. Mean theo weekday có thể thắng ML khi lịch sử ngắn hoặc đơn hàng nhiễu. Baseline thắng vẫn là kết quả hợp lệ.

**Tại sao chọn mô hình bằng MASE nhưng vẫn báo cáo WAPE?**
MASE cân bằng thang đo giữa thị trường. WAPE gần cách nhìn sai số theo khối lượng nhưng bị thị trường lớn chi phối. Hai metric trả lời hai góc nhìn; không giấu metric bất lợi.

**Khoảng 95% có chắc chứa 95% actual không?**
Không có bảo đảm đó trong dữ liệu phụ thuộc thời gian. Khoảng được hiệu chỉnh bằng 56 sai số trước test; mùa vụ, drift và mẫu nhỏ có thể làm độ phủ thấp. Phải báo cáo coverage thực nghiệm và width.

**Có thể dùng tổng upper_95 làm mức tồn kho an toàn không?**
Không. Cộng cận ngày không cho một khoảng 95% của tổng. Còn thiếu lead time, tồn kho hiện có, chi phí thiếu/dư hàng và phụ thuộc sai số giữa ngày.

**Vì sao không LSTM/Transformer?**
Không có bằng chứng cần kiến trúc đó với khoảng hai năm dữ liệu và năm chuỗi tổng hợp. Đánh giá đúng, baseline mạnh và kiểm thử leakage có giá trị hơn việc thêm tên mô hình. Muốn so sánh phải xác định protocol mới và giữ tập đánh giá ngoài mới.

**Bạn sẽ cải tiến gì trước?**
Thêm biến có sẵn tại thời điểm dự báo: tồn kho, lịch khuyến mại, lịch nghỉ, thay đổi giá dự kiến; kiểm tra độ đầy đủ dữ liệu và nhiều mùa đánh giá. Không dùng giá thực tế tương lai khi chưa biết trước giá đó.

## Dùng trong CV một cách trung thực
Có thể dùng khung tiếng Anh:

> Built a reproducible 28-day retail sales forecasting pipeline across five markets, comparing seasonal baselines, ETS, Ridge and gradient boosting with expanding-window validation and an untouched holdout; implemented label-date purging, empirical prediction intervals and temporal integrity tests.

Chỉ bổ sung mức giảm WAPE đã xác nhận từ `holdout_metrics.csv`, kèm phạm vi “on one 28-day historical holdout”. Không viết tiết kiệm chi phí, tác động kinh doanh thực tế hoặc triển khai production khi chưa có bằng chứng. Bạn cần tự chạy, hiểu và điều chỉnh project trước khi nhận là sản phẩm mình làm chủ.
