# RetailCast
### Auditable 28-day retail sales forecasting

A Data Science portfolio project using actual retail transactions. Six candidate models, origin-safe multi-horizon features, expanding-window validation, empirical uncertainty intervals and a separately held-out final test window.

**Start with [the offline interactive demo](DEMO.html)** — download and open it in a browser. No server, account or internet connection required. [Vietnamese results report](reports/BAO_CAO_KET_QUA.md) · [Executed research notebook](notebooks/01_research.ipynb) · [Methodology](docs/METHODOLOGY.md) · [Interview guide](docs/HUONG_DAN_PHONG_VAN.md).

![Validation comparison](reports/figures/validation_leaderboard.png)

## What problem does this solve?
At the start of each forecast window, predict daily gross positive merchandise units for the next 28 days across five countries. This provides a basis for workload planning and forecasting discussions. Sales are not stockout-adjusted demand, and the project does not claim inventory cost savings.

The source is [UCI Online Retail II](https://archive.ics.uci.edu/dataset/502/online+retail+ii), Chen, D. (2012), DOI: 10.24432/C5CG6D, CC BY 4.0. Both sheets contain 1,067,371 transaction rows. The processed panel covers 2009-12-01 to 2011-12-08. Five markets are selected only from the initial training history. Customer identifiers are not exported.

## Measured result
On the single final holdout **2011-11-11 → 2011-12-08**:

| Forecast strategy | WAPE | Mean seasonal MASE |
|---|---:|---:|
| Locked per-market champions | 26.6% | 0.645 |
| Repeat last week | 35.4% | 0.867 |
| 8-week weekday mean | 28.5% | 0.746 |

Relative WAPE reduction versus repeating the last week: **+24.9%**. A negative value means worse performance. Combined WAPE is dominated by large markets; inspect market-level MASE, bias and interval coverage before interpreting the result. One 28-day holdout does not establish generalization across seasons. No model choice was changed after evaluating the holdout.

## Why the evaluation is credible
1. The 196 final complete days form 4 validation windows, 2 calibration windows and 1 final holdout, each 28 days long.
2. Candidate selection uses mean validation MASE separately for each market. Baselines may win.
3. Supervised examples are purged by **label date**, preventing future labels from leaking through historical multi-step origins.
4. Lags and rolling statistics stay frozen for all 28 horizons; no actual values from inside the forecast window are fed back.
5. Calibration residuals come from windows after selection and before the test period.
6. All errors, baseline comparisons, coverage, cleaning rules and source hashes are exported.

## Models
Seasonal naive; 8-week weekday mean; weekly ETS with damped additive trend; global direct Ridge; two global direct histogram gradient boosting models with Poisson loss. Ridge/GBM use horizon, calendar, origin lags, rolling statistics, weekday profile and an available 364-day seasonal anchor. This is a predefined small model comparison, not an exhaustive search. No random split or random early-stopping validation is used.

## Run locally
Python 3.11–3.13; Python 3.12 is the tested runtime. Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-lock.txt
python -m pip install -e . --no-deps
python -m pytest -q
python scripts/audit_artifacts.py
retailcast run
python -m streamlit run app.py
```

On macOS/Linux replace the activation line with `source .venv/bin/activate`.
For a smaller install with compatible rather than exact tested versions: `python -m pip install -e ".[dev]"`.
The supplied processed data is enough for `retailcast run`, with no data download. For full raw-data reproduction:

```powershell
retailcast run --refresh
```

This downloads the ~43.5 MiB workbook from UCI and reprocesses it. Original transport can be slow; see `data/raw/README.md` for the exact workbook hash and transparent mirror provenance used in this run. Modelling and results generation finished in 149 seconds on the execution machine, including raw reading when applicable; runtime depends on hardware and storage. The portable ZIP excludes the raw workbook and Python environment.

## Repository map
```text
app.py                      Streamlit experiment review app
DEMO.html                   Standalone offline dashboard
src/retailcast/              Data, features, models, evaluation, pipeline, reports
data/processed/              Daily panel, audit and source provenance
notebooks/01_research.ipynb  Executed exploration and reproducibility checks
reports/                    Scores, predictions, intervals, split dates and figures
docs/                       Methodology and Vietnamese interview guide
tests/                      Data contracts and temporal integrity tests
scripts/audit_artifacts.py   Reconcile delivered artifacts against source panel
```

## Research artifacts
- `validation_predictions.csv`, `validation_by_fold.csv`, `validation_by_market.csv`: full candidate comparisons.
- `locked_selection.json`: pre-calibration algorithm choices and configuration.
- `calibration_predictions.csv`, `interval_calibration.json`: independent calibration evidence.
- `holdout_predictions.csv`, `holdout_metrics.csv`, `holdout_by_market.csv`: final measured results.
- `errors_by_horizon.csv`, `errors_by_weekday.csv`, `largest_errors.csv`: failure analysis.
- `interval_metrics.csv`: empirical coverage, mean width and interval scores.
- `forecast_28d.csv`: continuation after the historical endpoint, not a forecast for 2026.
- `run_summary.json`: configuration, versions, feature list and processed-data SHA-256.

## Limits and next steps
This retailer sells gifts and has wholesale customers; outliers and Christmas effects matter. Two years of data provide little evidence about annual stability. Exact duplicates and zero-filled dates rely on explicit assumptions. No stock availability, promotion calendar, future price plan or lead-time data is available. Empirical intervals use only 56 earlier errors per market and may under-cover during shifts; daily bounds cannot be summed into a calibrated monthly-total interval. The continuation's outcomes are unobserved.

The next useful improvement is better decision-time data and more independent seasonal evaluation, then SKU hierarchy and inventory-policy simulation with real business costs. This portfolio package is not a deployed production service.

## License
Code: MIT. Original and derived data: CC BY 4.0 with attribution to Chen, D. and UCI. See LICENSE and data provenance. Project code is provided as a starting point to study, reproduce and extend; explain your actual contribution honestly when applying.
